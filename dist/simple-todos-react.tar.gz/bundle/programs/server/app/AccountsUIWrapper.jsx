(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// AccountsUIWrapper.jsx                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
AccountsUIWrapper = React.createClass({                                // 1
  displayName: "AccountsUIWrapper",                                    //
                                                                       //
  componentDidMount: function () {                                     // 2
    // Use Meteor Blaze to render login buttons                        //
    this.view = Blaze.render(Template.loginButtons, React.findDOMNode(this.refs.container));
  },                                                                   //
  componentWillUnmount: function () {                                  // 7
    // Clean up Blaze view                                             //
    Blaze.remove(this.view);                                           // 9
  },                                                                   //
  render: function () {                                                // 11
    // Just render a placeholder container that will be filled in      //
    return React.createElement("span", { ref: "container" });          // 13
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=AccountsUIWrapper.jsx.map
