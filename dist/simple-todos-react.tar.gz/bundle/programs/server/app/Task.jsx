(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// Task.jsx                                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Task component - represents a single todo item                      //
Task = React.createClass({                                             // 2
  displayName: "Task",                                                 //
                                                                       //
  propTypes: {                                                         // 3
    // This component gets the task to display through a React prop.   //
    // We can use propTypes to indicate it is required                 //
    task: React.PropTypes.object.isRequired,                           // 6
    showPrivateButton: React.PropTypes.bool.isRequired                 // 7
  },                                                                   //
                                                                       //
  toggleChecked: function () {                                         // 10
    Meteor.call("setChecked", this.props.task._id, !this.props.task.checked);
  },                                                                   //
                                                                       //
  deleteThisTask: function () {                                        // 14
    Meteor.call("removeTask", this.props.task._id);                    // 15
  },                                                                   //
                                                                       //
  togglePrivate: function () {                                         // 18
    Meteor.call("setPrivate", this.props.task._id, !this.props.task["private"]);
  },                                                                   //
                                                                       //
  render: function () {                                                // 22
    // Give tasks a different className when they are checked off,     //
    // so that we can style them nicely in CSS                         //
    // Add "checked" and/or "private" to the className when needed     //
    var taskClassName = (this.props.task.checked ? "checked" : "") + " " + (this.props.task["private"] ? "private" : "");
                                                                       //
    return React.createElement(                                        // 29
      "li",                                                            //
      { className: taskClassName },                                    //
      React.createElement(                                             //
        "button",                                                      //
        { className: "delete", onClick: this.deleteThisTask },         //
        "×"                                                            //
      ),                                                               //
      React.createElement("input", {                                   //
        type: "checkbox",                                              // 36
        readOnly: true,                                                // 37
        checked: this.props.task.checked,                              // 38
        onClick: this.toggleChecked }),                                // 39
      this.props.showPrivateButton ? React.createElement(              //
        "button",                                                      //
        { className: "toggle-private", onClick: this.togglePrivate },  //
        this.props.task["private"] ? "Private" : "Public"              //
      ) : '',                                                          //
      React.createElement(                                             //
        "span",                                                        //
        { className: "text" },                                         //
        React.createElement(                                           //
          "strong",                                                    //
          null,                                                        //
          this.props.task.username                                     //
        ),                                                             //
        ": ",                                                          //
        this.props.task.text                                           //
      )                                                                //
    );                                                                 //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=Task.jsx.map
