(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// App.jsx                                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// App component - represents the whole app                            //
App = React.createClass({                                              // 2
  displayName: "App",                                                  //
                                                                       //
  // This mixin makes the getMeteorData method work                    //
  mixins: [ReactMeteorData],                                           // 5
                                                                       //
  getInitialState: function () {                                       // 7
    return {                                                           // 8
      hideCompleted: false                                             // 9
    };                                                                 //
  },                                                                   //
                                                                       //
  toggleHideCompleted: function () {                                   // 13
    this.setState({                                                    // 14
      hideCompleted: !this.state.hideCompleted                         // 15
    });                                                                //
  },                                                                   //
                                                                       //
  // Loads items from the Tasks collection and puts them on this.data.tasks
  getMeteorData: function () {                                         // 20
    var query = {};                                                    // 21
                                                                       //
    if (this.state.hideCompleted) {                                    // 23
      // If hide completed is checked, filter tasks                    //
      query = { checked: { $ne: true } };                              // 25
    }                                                                  //
                                                                       //
    return {                                                           // 28
      tasks: Tasks.find(query, { sort: { createdAt: -1 } }).fetch(),   // 29
      incompleteCount: Tasks.find({ checked: { $ne: true } }).count(),
      currentUser: Meteor.user()                                       // 31
    };                                                                 //
  },                                                                   //
                                                                       //
  renderTasks: function () {                                           // 35
    var _this = this;                                                  //
                                                                       //
    // Get tasks from this.data.tasks                                  //
    return this.data.tasks.map(function (task) {                       // 37
      var currentUserId = _this.data.currentUser && _this.data.currentUser._id;
      var showPrivateButton = task.owner === currentUserId;            // 39
                                                                       //
      return React.createElement(Task, {                               // 41
        key: task._id,                                                 // 42
        task: task,                                                    // 43
        showPrivateButton: showPrivateButton });                       // 44
    });                                                                //
  },                                                                   //
                                                                       //
  handleSubmit: function (event) {                                     // 48
    event.preventDefault();                                            // 49
                                                                       //
    // Find the text field via the React ref                           //
    var text = React.findDOMNode(this.refs.textInput).value.trim();    // 52
                                                                       //
    Meteor.call("addTask", text);                                      // 54
                                                                       //
    // Clear form                                                      //
    React.findDOMNode(this.refs.textInput).value = "";                 // 57
  },                                                                   //
                                                                       //
  render: function () {                                                // 60
    return React.createElement(                                        // 61
      "div",                                                           //
      { className: "container" },                                      //
      React.createElement(                                             //
        "header",                                                      //
        null,                                                          //
        React.createElement(                                           //
          "h1",                                                        //
          null,                                                        //
          "Todo List (",                                               //
          this.data.incompleteCount,                                   //
          ")"                                                          //
        ),                                                             //
        React.createElement(                                           //
          "label",                                                     //
          { className: "hide-completed" },                             //
          React.createElement("input", {                               //
            type: "checkbox",                                          // 68
            readOnly: true,                                            // 69
            checked: this.state.hideCompleted,                         // 70
            onClick: this.toggleHideCompleted }),                      // 71
          "Hide Completed Tasks"                                       //
        ),                                                             //
        React.createElement(AccountsUIWrapper, null),                  //
        this.data.currentUser ? React.createElement(                   //
          "form",                                                      //
          { className: "new-task", onSubmit: this.handleSubmit },      //
          React.createElement("input", {                               //
            type: "text",                                              // 80
            ref: "textInput",                                          // 81
            placeholder: "Type to add new tasks" })                    // 82
        ) : ''                                                         //
      ),                                                               //
      React.createElement(                                             //
        "ul",                                                          //
        null,                                                          //
        this.renderTasks()                                             //
      )                                                                //
    );                                                                 //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=App.jsx.map
