(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// simple-todos-react.jsx                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Define a collection to hold our tasks                               //
Tasks = new Mongo.Collection("tasks");                                 // 2
                                                                       //
if (Meteor.isClient) {                                                 // 4
  // This code is executed on the client only                          //
                                                                       //
  Accounts.ui.config({                                                 // 7
    passwordSignupFields: "USERNAME_ONLY"                              // 8
  });                                                                  //
                                                                       //
  Meteor.subscribe("tasks");                                           // 11
                                                                       //
  Meteor.startup(function () {                                         // 13
    // Use Meteor.startup to render the component after the page is ready
    React.render(React.createElement(App, null), document.getElementById("render-target"));
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
  // Only publish tasks that are public or belong to the current user  //
  Meteor.publish("tasks", function () {                                // 21
    return Tasks.find({                                                // 22
      $or: [{ "private": { $ne: true } }, { owner: this.userId }]      // 23
    });                                                                //
  });                                                                  //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 31
  addTask: function (text) {                                           // 32
    // Make sure the user is logged in before inserting a task         //
    if (!Meteor.userId()) {                                            // 34
      throw new Meteor.Error("not-authorized");                        // 35
    }                                                                  //
                                                                       //
    Tasks.insert({                                                     // 38
      text: text,                                                      // 39
      createdAt: new Date(),                                           // 40
      owner: Meteor.userId(),                                          // 41
      username: Meteor.user().username                                 // 42
    });                                                                //
  },                                                                   //
                                                                       //
  removeTask: function (taskId) {                                      // 46
    var task = Tasks.findOne(taskId);                                  // 47
    if (task["private"] && task.owner !== Meteor.userId()) {           // 48
      // If the task is private, make sure only the owner can delete it
      throw new Meteor.Error("not-authorized");                        // 50
    }                                                                  //
                                                                       //
    Tasks.remove(taskId);                                              // 53
  },                                                                   //
                                                                       //
  setChecked: function (taskId, setChecked) {                          // 56
    var task = Tasks.findOne(taskId);                                  // 57
    if (task["private"] && task.owner !== Meteor.userId()) {           // 58
      // If the task is private, make sure only the owner can check it off
      throw new Meteor.Error("not-authorized");                        // 60
    }                                                                  //
                                                                       //
    Tasks.update(taskId, { $set: { checked: setChecked } });           // 63
  },                                                                   //
                                                                       //
  setPrivate: function (taskId, setToPrivate) {                        // 66
    var task = Tasks.findOne(taskId);                                  // 67
                                                                       //
    // Make sure only the task owner can make a task private           //
    if (task.owner !== Meteor.userId()) {                              // 70
      throw new Meteor.Error("not-authorized");                        // 71
    }                                                                  //
                                                                       //
    Tasks.update(taskId, { $set: { "private": setToPrivate } });       // 74
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=simple-todos-react.jsx.map
